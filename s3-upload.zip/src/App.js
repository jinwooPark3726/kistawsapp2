import './App.css';
import UploadImage from './UploadImage.js';
function App() {
  return (
  <UploadImage/>
  );
}

export default App;
